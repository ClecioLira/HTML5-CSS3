Brothersoft only provide the host for the game.
The copyright belong to the game author.

http://www.brothersoft.com/?referral=classicalgames

More games
http://www.brothersoft.com/games/?referral=classicalgames